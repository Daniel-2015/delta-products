Delta (R)/TM

Please, always go to the disk_rom folder in order to install games