document.addEventListener("DOMContentLoaded", () => {
    const MemoryCard = {};
    MemoryCard.set = (name) => {
        if (MemoryCard.name) throw new Error("Project address has already been declared");
        MemoryCard.name = "WSX_" + name;    
        MemoryCard.data = localStorage.getItem(MemoryCard.name);
        MemoryCard.data = JSON.parse(MemoryCard.data || "{}");
    };
    MemoryCard.read = (key) => MemoryCard.data[key];
    MemoryCard.write = (key, load) => MemoryCard.data[key] = load;
    MemoryCard.clear = () => {
        MemoryCard.data = {};
        localStorage.removeItem(MemoryCard.name);
    };
    MemoryCard.save = () => localStorage.setItem(MemoryCard.name, JSON.stringify(MemoryCard.data));
    MemoryCard.help = () => Object.keys(MemoryCard);

    if (typeof init !== "function") throw new Error("Init function is not defined");
    init();

    if (typeof loop === "function") {
        let start = performance.now();
        (function loop2() {
            const dtms = performance.now() - start;
            start = performance.now();
            loop(dtms / 1000); // tiempo en segundos
            requestAnimationFrame(loop2);
        })();
    }
});
