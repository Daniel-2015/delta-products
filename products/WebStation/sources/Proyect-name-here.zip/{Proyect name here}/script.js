// If you want memory usage, run `MemoryCard.help();`

function init() {
	// Your code here
}

function loop(dt) {
	// Your loop code here
	// No need for `requestAnimationFrame`
}